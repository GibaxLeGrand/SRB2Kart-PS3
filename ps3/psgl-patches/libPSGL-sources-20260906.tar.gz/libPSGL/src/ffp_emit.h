#ifndef PS3DK_LIBPSGL_FFP_EMIT_H
#define PS3DK_LIBPSGL_FFP_EMIT_H

#include <stddef.h>
#include <stdint.h>

#define PSGL_FFP_MINIMAL_MASK 0x00000001u
#define PSGL_FFP_LIGHTING_MASK 0x00000002u
#define PSGL_FFP_FOG_MASK 0x00000004u
#define PSGL_FFP_POSITION_ONLY_MASK 0x00000008u
#define PSGL_SHADER_LIBRARY_VERSION 1u

/* 2026-09-02 -- cles texenv.
 *
 * Le pipeline fixe d'origine n'avait que trois programmes et ignorait
 * GL_TEXTURE_ENV_MODE : glTexEnvi etait un corps vide, et le shader "minimal"
 * appliquait de fait GL_REPLACE (la couleur de sommet etait perdue). Pire :
 * des qu'une SECONDE unite de texture etait active, psgl_ffp_state_mask()
 * renvoyait 0, donc aucun programme n'etait lie et le dessin partait au RSX
 * sans shader du tout.
 *
 * On reprend ici la conception d'IoQuake3-PS3 (code/gl/ps3gl.h) : un vertex
 * program unique, un fragment program par mode texenv, choisis par une cle.
 * Meme numerotation qu'eux, pour que les deux sources restent comparables.
 *
 * La cle occupe les bits 16..19, hors des bits deja pris par les lumieres
 * (8..8+PSGL_MAX_LIGHTS).
 */
#define PSGL_FFP_TEXENV_SHIFT 16u
#define PSGL_FFP_TEXENV_MASK 0x000f0000u

#define PSGL_FFP_TEXENV_DISABLED 0u
#define PSGL_FFP_TEXENV_MODULATE 1u
#define PSGL_FFP_TEXENV_REPLACE 2u
#define PSGL_FFP_TEXENV_DECAL 3u
#define PSGL_FFP_TEXENV_ADD 4u
#define PSGL_FFP_TEXENV_BLEND 5u
#define PSGL_FFP_TEXENV_MODULATE2 6u
#define PSGL_FFP_TEXENV_COUNT 7u

#define PSGL_FFP_TEXENV_KEY(mask) \
    (((mask) & PSGL_FFP_TEXENV_MASK) >> PSGL_FFP_TEXENV_SHIFT)

int psgl_ffp_state_mask_to_cg(uint32_t mask,
                              char *vp_source, size_t vp_capacity,
                              char *fp_source, size_t fp_capacity);

#endif
