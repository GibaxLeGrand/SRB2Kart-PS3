build-lp64/cgc_compiler.o: src/cgc_compiler.c \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/cgc.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/string.h
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/cgc.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/string.h:
