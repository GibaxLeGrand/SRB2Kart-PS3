build-lp64/cg_runtime.o: src/cg_runtime.c src/cg_internal.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/cgBinary.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/cg.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/NV/cg.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/stdarg.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/cg_types.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/NV/cg_types.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/cg_datatypes.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/NV/cg_datatypes.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/cg_bindlocations.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/NV/cg_bindlocations.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/cg_profiles.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/NV/cg_profiles.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/cgGL_profiles.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/NV/cgGL_profiles.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/cg_errors.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/NV/cg_errors.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/cg_enums.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/NV/cg_enums.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/cgGL.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/NV/cgGL.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/GLES/gl.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/PSGL/export.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/cell/cgb.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/cell/cgb/cgb_struct.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/cell/cgb/cgb_levelc.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/ppu-types.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/stdlib.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/sys/types.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/sys/sys_types.h
src/cg_internal.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/cgBinary.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/cg.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/NV/cg.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/stdarg.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/cg_types.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/NV/cg_types.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/cg_datatypes.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/NV/cg_datatypes.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/cg_bindlocations.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/NV/cg_bindlocations.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/cg_profiles.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/NV/cg_profiles.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/cgGL_profiles.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/NV/cgGL_profiles.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/cg_errors.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/NV/cg_errors.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/cg_enums.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/NV/cg_enums.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/cgGL.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/NV/cgGL.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/GLES/gl.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/PSGL/export.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/cell/cgb.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/cell/cgb/cgb_struct.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/cell/cgb/cgb_levelc.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/ppu-types.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/stdlib.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/sys/types.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/sys/sys_types.h:
