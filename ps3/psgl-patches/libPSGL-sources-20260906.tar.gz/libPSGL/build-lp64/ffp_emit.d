build-lp64/ffp_emit.o: src/ffp_emit.c src/ffp_emit.h
src/ffp_emit.h:
