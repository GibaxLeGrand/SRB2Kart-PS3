build-lp64/psgl_command_buffer.o: src/psgl_command_buffer.c \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/PSGL/psgl.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/stdlib.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/PSGL/export.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/GLES/gl.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/GLES/glext.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/cg.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/NV/cg.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/stdarg.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/cg_types.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/NV/cg_types.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/cg_datatypes.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/NV/cg_datatypes.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/cg_bindlocations.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/NV/cg_bindlocations.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/cg_profiles.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/NV/cg_profiles.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/cgGL_profiles.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/NV/cgGL_profiles.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/cg_errors.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/NV/cg_errors.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/cg_enums.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/NV/cg_enums.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/cgGL.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/NV/cgGL.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/PSGL/report.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/cell/cgb/cgb_struct.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/cell/resc.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/cell/cell_video_out.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/cell/error.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/cell/gcm.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/ppu-types.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/sys/types.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/sys/sys_types.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/rsx/gcm_sys.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/rsx/rsx.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/rsx/mm.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/rsx/rsx_program.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/rsx/commands.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/rsx/rsx_function_macros.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/rsx/commands_inc.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/cgBinary.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/sys/lv2_types.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/sys/timer.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/sys/lv2_syscall.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/cell/gcm/ps3tc_fifo_wrap.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/cell/gcm/gcm_enum.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/cell/gcm/gcm_cg_func.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/cell/gcm/gcm_cg_bridge.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/string.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/rsx/nv40.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/cell/gcm/gcm_command_c.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/cell/gcm/gcm_tex_bridge.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/cell/gcm/gcm_cmd_overloads.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/sdk_version.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/cell/sdk_version.h \
 src/psgl_command_buffer.h src/psgl_context.h
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/PSGL/psgl.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/stdlib.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/PSGL/export.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/GLES/gl.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/GLES/glext.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/cg.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/NV/cg.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/stdarg.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/cg_types.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/NV/cg_types.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/cg_datatypes.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/NV/cg_datatypes.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/cg_bindlocations.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/NV/cg_bindlocations.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/cg_profiles.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/NV/cg_profiles.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/cgGL_profiles.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/NV/cgGL_profiles.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/cg_errors.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/NV/cg_errors.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/cg_enums.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/NV/cg_enums.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/cgGL.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/NV/cgGL.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/PSGL/report.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/cell/cgb/cgb_struct.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/cell/resc.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/cell/cell_video_out.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/cell/error.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/cell/gcm.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/ppu-types.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/sys/types.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/sys/sys_types.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/rsx/gcm_sys.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/rsx/rsx.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/rsx/mm.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/rsx/rsx_program.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/rsx/commands.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/rsx/rsx_function_macros.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/rsx/commands_inc.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/Cg/cgBinary.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/sys/lv2_types.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/sys/timer.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/sys/lv2_syscall.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/cell/gcm/ps3tc_fifo_wrap.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/cell/gcm/gcm_enum.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/cell/gcm/gcm_cg_func.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/cell/gcm/gcm_cg_bridge.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/string.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/rsx/nv40.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/cell/gcm/gcm_command_c.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/cell/gcm/gcm_tex_bridge.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/cell/gcm/gcm_cmd_overloads.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/sdk_version.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/cell/sdk_version.h:
src/psgl_command_buffer.h:
src/psgl_context.h:
