build-lp64/report.o: src/report.c \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/PSGL/report.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/PSGL/export.h \
 /home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/GLES/gl.h
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/PSGL/report.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/PSGL/export.h:
/home/comodore/PS3DK/stage/ps3dev/ps3dk/ppu/include/GLES/gl.h:
